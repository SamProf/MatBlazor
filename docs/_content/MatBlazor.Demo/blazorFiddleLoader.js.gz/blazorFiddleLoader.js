﻿(function() {
    var script = document.createElement("script"); // create a script DOM node
    script.src = "https://blazorfiddle.com/scripts/blazorFiddle.js"; // set its src to the provided URL

    document.head.appendChild(script);
})();