﻿var matBlazorDemo = {
    innerWidth: function() {
        return window.innerWidth;
    }, 

    initAd: function(){
        (window.adsbygoogle = window.adsbygoogle || []).push({})
    },
    
    
    
    
    test: function (a,b,c) {
        console.log(arguments);
        debugger;
    }
};